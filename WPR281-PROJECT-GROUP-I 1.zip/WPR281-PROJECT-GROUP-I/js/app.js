seedAppData();

const UI_SETTINGS_KEY = "uiSettings";

function getUISettings() {
  const savedSettings = localStorage.getItem(UI_SETTINGS_KEY);
  return savedSettings ? JSON.parse(savedSettings) : { theme: "light" };
}

function saveUISettings(settings) {
  localStorage.setItem(UI_SETTINGS_KEY, JSON.stringify(settings));
}

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  document.body.setAttribute("data-theme", theme);

  const themeToggleBtn = document.getElementById("themeToggleBtn");
  const themeToggleText = document.getElementById("themeToggleText");

  if (themeToggleBtn) {
    themeToggleBtn.setAttribute("aria-label", `Switch to ${theme === "light" ? "dark" : "light"} mode`);
  }

  if (themeToggleText) {
    themeToggleText.textContent = theme === "light" ? "Dark Mode" : "Light Mode";
  }
}

function initializeTheme() {
  const settings = getUISettings();
  const theme = settings.theme || "light";

  applyTheme(theme);

  const themeToggleBtn = document.getElementById("themeToggleBtn");

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener("click", function () {
      const currentSettings = getUISettings();
      const newTheme = currentSettings.theme === "dark" ? "light" : "dark";

      currentSettings.theme = newTheme;
      saveUISettings(currentSettings);
      applyTheme(newTheme);
    });
  }
}

initializeTheme();


if (document.getElementById("issuesList")) {
  renderRecentIssues();
  renderIssues();
  updateIssueCounts();
  populateProjectOptions();
  populatePeopleOptions();
  populateEditProjectOptions();
  populateEditPeopleOptions();

  const searchInput = document.getElementById("searchInput");
  const statusFilter = document.getElementById("statusFilter");
  const priorityFilter = document.getElementById("priorityFilter");
  const createIssueForm = document.getElementById("createIssueForm");
  const editIssueForm = document.getElementById("editIssueForm");
  const issuesList = document.getElementById("issuesList");
  const editIssueBtn = document.getElementById("editIssueBtn");
  const deleteIssueBtn = document.getElementById("deleteIssueBtn");

  if (searchInput) {
    searchInput.addEventListener("input", filterIssues);
  }

  if (statusFilter) {
    statusFilter.addEventListener("change", filterIssues);
  }

  if (priorityFilter) {
    priorityFilter.addEventListener("change", filterIssues);
  }

  if (createIssueForm) {
    createIssueForm.addEventListener("submit", handleCreateIssue);
  }

  if (editIssueForm) {
    editIssueForm.addEventListener("submit", handleEditIssue);
  }

  if (issuesList) {
    issuesList.addEventListener("click", function (event) {
      const clickedCard = event.target.closest(".issue-card");

      if (!clickedCard) return;

      const issueId = Number(clickedCard.dataset.issueId);
      openIssueDetails(issueId);
    });
  }

  if (editIssueBtn) {
    editIssueBtn.addEventListener("click", function () {
      if (currentViewedIssueId !== null) {
        openEditIssueModal(currentViewedIssueId);
      }
    });
  }

  if (deleteIssueBtn) {
    deleteIssueBtn.addEventListener("click", handleDeleteIssue);
  }
}

if (document.getElementById("peopleGrid")) {
  renderPeople();
}

if (document.getElementById("projectsList")) {
  renderProjects();
  setupProjectToggles();
}