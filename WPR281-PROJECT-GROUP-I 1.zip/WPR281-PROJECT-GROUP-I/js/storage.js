const STORAGE_KEYS = {
  ISSUES: "issues",
  PEOPLE: "people",
  PROJECTS: "projects",
};

function getData(key) {
  const storedData = localStorage.getItem(key);
  return storedData ? JSON.parse(storedData) : [];
}

function saveData(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function hasData(key) {
  return localStorage.getItem(key) !== null;
}

function clearData(key) {
  localStorage.removeItem(key);
}

function clearAllAppData() {
  Object.values(STORAGE_KEYS).forEach(function (key) {
    localStorage.removeItem(key);
  });
}