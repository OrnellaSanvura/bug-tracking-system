function getIssuesByProjectId(projectId) {
  const issues = getIssues();

  return issues.filter(function (issue) {
    return issue.projectId === projectId;
  });
}

function getProjectStats(projectId) {
  const projectIssues = getIssuesByProjectId(projectId);

  const openCount = projectIssues.filter(function (issue) {
    return issue.status === "open";
  }).length;

  const resolvedCount = projectIssues.filter(function (issue) {
    return issue.status === "resolved";
  }).length;

  const overdueCount = projectIssues.filter(function (issue) {
    return issue.status === "overdue";
  }).length;

  return {
    total: projectIssues.length,
    open: openCount,
    resolved: resolvedCount,
    overdue: overdueCount
  };
}

function createProjectItem(project) {
  const stats = getProjectStats(project.id);

  return `
    <div class="project-item">
      <button class="project-toggle" data-project-id="${project.id}" type="button">
        <span class="project-name">${project.name}</span>
        <span class="project-toggle-icon">+</span>
      </button>

      <div class="project-details d-none" id="project-details-${project.id}">
        <div class="project-details-grid">
          <div class="project-detail-box">
            <span class="project-detail-label">Project ID</span>
            <span class="project-detail-value">${project.id}</span>
          </div>

          <div class="project-detail-box">
            <span class="project-detail-label">Created</span>
            <span class="project-detail-value">${project.createdDate || "Not set"}</span>
          </div>

          <div class="project-detail-box">
            <span class="project-detail-label">Total Issues</span>
            <span class="project-detail-value">${stats.total}</span>
          </div>

          <div class="project-detail-box">
            <span class="project-detail-label">Open</span>
            <span class="project-detail-value">${stats.open}</span>
          </div>

          <div class="project-detail-box">
            <span class="project-detail-label">Resolved</span>
            <span class="project-detail-value">${stats.resolved}</span>
          </div>

          <div class="project-detail-box">
            <span class="project-detail-label">Overdue</span>
            <span class="project-detail-value">${stats.overdue}</span>
          </div>
        </div>
      </div>
    </div>
  `;
}

function renderProjects() {
  const projectsList = document.getElementById("projectsList");
  const projectsEmptyState = document.getElementById("projectsEmptyState");

  if (!projectsList || !projectsEmptyState) return;

  const projects = getProjects();

  if (projects.length === 0) {
    projectsList.innerHTML = "";
    projectsEmptyState.classList.remove("d-none");
    return;
  }

  projectsEmptyState.classList.add("d-none");

  const items = projects.map(function (project) {
    return createProjectItem(project);
  });

  projectsList.innerHTML = items.join("");
}

function setupProjectToggles() {
  const projectsList = document.getElementById("projectsList");
  if (!projectsList) return;

  projectsList.addEventListener("click", function (event) {
    const toggleButton = event.target.closest(".project-toggle");
    if (!toggleButton) return;

    const projectId = toggleButton.dataset.projectId;
    const details = document.getElementById(`project-details-${projectId}`);
    const icon = toggleButton.querySelector(".project-toggle-icon");

    if (!details || !icon) return;

    const isHidden = details.classList.contains("d-none");

    details.classList.toggle("d-none");

    icon.textContent = isHidden ? "−" : "+";
  });
}