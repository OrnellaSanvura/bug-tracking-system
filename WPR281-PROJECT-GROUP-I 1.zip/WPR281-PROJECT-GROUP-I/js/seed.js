 function seedPeople() {
  const people = [
    {
      id: 1,
      name: "Sarah",
      surname: "Doe",
      email: "sarah.doe@bugtracker.dev",
      username: "sdoe",
      profilePicture: "https://i.pravatar.cc/150?img=32",
      yearsExperience: 5,
      role: "Senior Developer"
    },
    {
      id: 2,
      name: "Marcus",
      surname: "Smith",
      email: "marcus.smith@bugtracker.dev",
      username: "msmith",
      profilePicture: "https://i.pravatar.cc/150?img=12",
      yearsExperience: 2,
      role: "Junior Developer"
    },
    {
      id: 3,
      name: "Jamie",
      surname: "Lee",
      email: "jamie.lee@bugtracker.dev",
      username: "jlee",
      profilePicture: "https://i.pravatar.cc/150?img=47",
      yearsExperience: 4,
      role: "Mid-Level Developer"
    },
    {
      id: 4,
      name: "Liam",
      surname: "Parker",
      email: "liam.parker@bugtracker.dev",
      username: "lparker",
      profilePicture: "https://i.pravatar.cc/150?img=15",
      yearsExperience: 6,
      role: "Senior QA Engineer"
    },
    {
      id: 5,
      name: "Ava",
      surname: "Johnson",
      email: "ava.johnson@bugtracker.dev",
      username: "ajohnson",
      profilePicture: "https://i.pravatar.cc/150?img=5",
      yearsExperience: 3,
      role: "Frontend Developer"
    },
    {
      id: 6,
      name: "Noah",
      surname: "Williams",
      email: "noah.williams@bugtracker.dev",
      username: "nwilliams",
      profilePicture: "https://i.pravatar.cc/150?img=22",
      yearsExperience: 7,
      role: "Technical Lead"
    }
  ];

  saveData(STORAGE_KEYS.PEOPLE, people);
}

function seedProjects() {
  const projects = [
    { id: 1, name: "Bug Tracker System", createdDate: "2026-03-10" },
    { id: 2, name: "Customer Portal", createdDate: "2026-03-18" },
    { id: 3, name: "Inventory Dashboard", createdDate: "2026-03-25" }
  ];

  saveData(STORAGE_KEYS.PROJECTS, projects);
}

function seedIssues() {
  const issues = [
    {
      id: 1,
      summary: "Login button does not respond",
      description: "The login button does nothing when clicked on the homepage.",
      identifiedBy: "Sarah Doe",
      dateIdentified: "2026-04-10",
      projectId: 1,
      assignedTo: 2,
      status: "open",
      priority: "high",
      targetResolutionDate: "2026-04-20",
      actualResolutionDate: "",
      resolutionSummary: "",
    },
    {
      id: 2,
      summary: "Profile image not displaying",
      description: "User profile image is broken after uploading a valid file.",
      identifiedBy: "Jamie Lee",
      dateIdentified: "2026-04-09",
      projectId: 1,
      assignedTo: 3,
      status: "resolved",
      priority: "medium",
      targetResolutionDate: "2026-04-15",
      actualResolutionDate: "2026-04-14",
      resolutionSummary: "Fixed image path handling.",
    },
    {
      id: 3,
      summary: "Dashboard cards overlap on mobile",
      description: "Cards stack incorrectly on smaller screen sizes.",
      identifiedBy: "Marcus Smith",
      dateIdentified: "2026-04-08",
      projectId: 2,
      assignedTo: 1,
      status: "overdue",
      priority: "high",
      targetResolutionDate: "2026-04-12",
      actualResolutionDate: "",
      resolutionSummary: "",
    },


    {
      id: 4,
      summary: "Search bar not filtering results",
      description: "Typing in the search bar does not filter the issues list.",
      identifiedBy: "Ava Johnson",
      dateIdentified: "2026-04-07",
      projectId: 2,
      assignedTo: 5,
      status: "open",
      priority: "medium",
      targetResolutionDate: "2026-04-18",
      actualResolutionDate: "",
      resolutionSummary: "",
    },
    {
      id: 5,
      summary: "Incorrect total issue count",
      description: "Dashboard shows incorrect number of total issues.",
      identifiedBy: "Noah Williams",
      dateIdentified: "2026-04-06",
      projectId: 3,
      assignedTo: 6,
      status: "resolved",
      priority: "low",
      targetResolutionDate: "2026-04-10",
      actualResolutionDate: "2026-04-09",
      resolutionSummary: "Fixed counting logic in dashboard.",
    },
    {
      id: 6,
      summary: "Dropdown menu overlaps content",
      description: "Dropdown menus cover other elements on smaller screens.",
      identifiedBy: "Liam Parker",
      dateIdentified: "2026-04-05",
      projectId: 1,
      assignedTo: 4,
      status: "overdue",
      priority: "medium",
      targetResolutionDate: "2026-04-11",
      actualResolutionDate: "",
      resolutionSummary: "",
    },
    {
      id: 7,
      summary: "Issue form not resetting after submit",
      description: "Form fields remain filled after submitting a new issue.",
      identifiedBy: "Sarah Doe",
      dateIdentified: "2026-04-04",
      projectId: 3,
      assignedTo: 2,
      status: "open",
      priority: "low",
      targetResolutionDate: "2026-04-19",
      actualResolutionDate: "",
      resolutionSummary: "",
    },
    {
      id: 8,
      summary: "Assigned user not displaying correctly",
      description: "Assigned user's name does not appear on issue card.",
      identifiedBy: "Marcus Smith",
      dateIdentified: "2026-04-03",
      projectId: 2,
      assignedTo: 3,
      status: "resolved",
      priority: "high",
      targetResolutionDate: "2026-04-08",
      actualResolutionDate: "2026-04-07",
      resolutionSummary: "Corrected mapping of user IDs.",
    },
    {
      id: 9,
      summary: "Date picker allows invalid dates",
      description: "Users can select past dates incorrectly in date picker.",
      identifiedBy: "Jamie Lee",
      dateIdentified: "2026-04-02",
      projectId: 1,
      assignedTo: 1,
      status: "overdue",
      priority: "low",
      targetResolutionDate: "2026-04-06",
      actualResolutionDate: "",
      resolutionSummary: "",
    },
    {
      id: 10,
      summary: "Priority filter not working",
      description: "Filtering by priority does not update the issue list.",
      identifiedBy: "Ava Johnson",
      dateIdentified: "2026-04-01",
      projectId: 3,
      assignedTo: 5,
      status: "open",
      priority: "high",
      targetResolutionDate: "2026-04-17",
      actualResolutionDate: "",
      resolutionSummary: "",
    }
  ];

  saveData(STORAGE_KEYS.ISSUES, issues);
}

  function seedAppData() {
    if (!hasData(STORAGE_KEYS.PEOPLE)) {
      seedPeople();
    }

    if (!hasData(STORAGE_KEYS.PROJECTS)) {
      seedProjects();
    }

    if (!hasData(STORAGE_KEYS.ISSUES)) {
      seedIssues();
    }
  }