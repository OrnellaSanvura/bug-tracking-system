function createPersonCard(person) {
  const completedTickets = getCompletedTicketsCount(person.id);

  return `
    <div class="col-md-6 col-lg-4">
      <div class="person-card h-100">
        <div class="person-card-body">
          <div class="person-avatar-wrapper mb-3">
            <img
              src="${person.profilePicture}"
              alt="${person.name} ${person.surname}"
              class="person-avatar"
            >
          </div>

          <h3 class="person-name mb-1">${person.name} ${person.surname}</h3>
          <p class="person-username mb-2">@${person.username}</p>
          <span class="person-role-badge mb-3 d-inline-block">${person.role}</span>

          <div class="person-stats mb-3">
            <div class="person-stat-box">
              <span class="person-stat-value">${person.yearsExperience}</span>
              <span class="person-stat-label">Years Exp.</span>
            </div>
            <div class="person-stat-box">
              <span class="person-stat-value">${completedTickets}</span>
              <span class="person-stat-label">Tickets Done</span>
            </div>
          </div>

          <div class="person-info">
            <p class="mb-2"><strong>ID:</strong> ${person.id}</p>
            <p class="mb-0"><strong>Email:</strong> ${person.email}</p>
          </div>
        </div>
      </div>
    </div>
  `;
}

function renderPeople() {
  const peopleGrid = document.getElementById("peopleGrid");
  const peopleEmptyState = document.getElementById("peopleEmptyState");

  if (!peopleGrid || !peopleEmptyState) return;

  const people = getPeople();

  if (people.length === 0) {
    peopleGrid.innerHTML = "";
    peopleEmptyState.classList.remove("d-none");
    return;
  }

  peopleEmptyState.classList.add("d-none");

  const cards = people.map(function (person) {
    return createPersonCard(person);
  });

  peopleGrid.innerHTML = cards.join("");
}


function getCompletedTicketsCount(personId) {
  const issues = getIssues();

  return issues.filter(function (issue) {
    return issue.assignedTo === personId && issue.status === "resolved";
  }).length;
}