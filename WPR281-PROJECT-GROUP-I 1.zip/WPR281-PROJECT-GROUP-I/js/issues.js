let currentViewedIssueId = null;
function getPeople() {
  return getData(STORAGE_KEYS.PEOPLE);
}







function getProjects() {
  return getData(STORAGE_KEYS.PROJECTS);
}

function getIssues() {
  return getData(STORAGE_KEYS.ISSUES);
}







function getPersonById(personId) {
  const people = getPeople();
  return people.find(function (person) {
    return person.id === personId;
  });
}

function getProjectById(projectId) {
  const projects = getProjects();
  return projects.find(function (project) {
    return project.id === projectId;
  });
}



function getStatusBadgeClass(status) {
  if (status === "open") return "bg-primary";
  if (status === "resolved") return "bg-success";
  if (status === "overdue") return "bg-danger";
  return "bg-secondary";
}

function getPriorityBadgeClass(priority) {
  if (priority === "low") return "bg-secondary";
  if (priority === "medium") return "bg-warning text-dark";
  if (priority === "high") return "bg-danger";
  return "bg-secondary";
}










function createIssueCard(issue) {
  const assignedPerson = getPersonById(issue.assignedTo);
  const project = getProjectById(issue.projectId);

  return `

    <div class="col-md-6 col-lg-4">
      <div class="card h-100 shadow-sm border-0 issue-card ${getIssueAccentClass(issue.status)}" data-issue-id="${issue.id}" style="cursor: pointer;">
        <div class="card-body p-4">
          <div class="d-flex justify-content-between align-items-start mb-3">
            <span class="badge ${getStatusBadgeClass(issue.status)} text-uppercase px-3 py-2">
              ${issue.status}
            </span>
            <span class="badge ${getPriorityBadgeClass(issue.priority)} text-uppercase px-3 py-2">
              ${issue.priority}
            </span>
          </div>




          <h5 class="card-title issue-card-title mb-2">${issue.summary}</h5>
          <p class="card-text issue-card-description mb-3">
            ${issue.description}
          </p>

          <div class="issue-meta">
            <p class="mb-2"><strong>Project:</strong> ${project ? project.name : "Unassigned"}</p>
            <p class="mb-2"><strong>Assigned To:</strong> ${assignedPerson ? assignedPerson.name + " " + assignedPerson.surname : "Unassigned"}</p>
            <p class="mb-2"><strong>Date Identified:</strong> ${issue.dateIdentified}</p>

            <p class="mb-0"><strong>Target Resolution:</strong> ${issue.targetResolutionDate || "Not set"}</p>
          </div>
        </div>
      </div>
    </div>
  `;
}

function renderIssues(filteredIssues = null) {
  const issuesList = document.getElementById("issuesList");
  const emptyState = document.getElementById("emptyState");

  if (!issuesList || !emptyState) return;

  const issuesToRender = filteredIssues || getIssues();

  if (issuesToRender.length === 0) {
    issuesList.innerHTML = "";
    emptyState.style.display = "block";



    return;
  }

  emptyState.style.display = "none";

  const issueCards = issuesToRender.map(function (issue) {
    return createIssueCard(issue);
  });

  issuesList.innerHTML = issueCards.join("");
}

function updateIssueCounts() {
  const issues = getIssues();

  const openCount = issues.filter(function (issue) {
    return issue.status === "open";
  }).length;

  const resolvedCount = issues.filter(function (issue) {
    return issue.status === "resolved";
  }).length;

  const overdueCount = issues.filter(function (issue) {
    return issue.status === "overdue";
  }).length;

  const openCountElement = document.getElementById("openCount");
  
  const resolvedCountElement = document.getElementById("resolvedCount");
  const overdueCountElement = document.getElementById("overdueCount");

  if (openCountElement) openCountElement.textContent = openCount;
  if (resolvedCountElement) resolvedCountElement.textContent = resolvedCount;
  if (overdueCountElement) overdueCountElement.textContent = overdueCount;
}

function filterIssues() {
  const searchInput = document.getElementById("searchInput");
  const statusFilter = document.getElementById("statusFilter");
  const priorityFilter = document.getElementById("priorityFilter");


  if (!searchInput || !statusFilter || !priorityFilter) return;

  const searchValue = searchInput.value.trim().toLowerCase();
  const statusValue = statusFilter.value;
  const priorityValue = priorityFilter.value;


  const issues = getIssues();

  const filteredIssues = issues.filter(function (issue) {
    const matchesSearch =
      issue.summary.toLowerCase().includes(searchValue) ||
      issue.description.toLowerCase().includes(searchValue);

    const matchesStatus =
      statusValue === "all" || issue.status === statusValue;

    const matchesPriority =



      priorityValue === "all" || issue.priority === priorityValue;

    return matchesSearch && matchesStatus && matchesPriority;
  });

  renderIssues(filteredIssues);


  
}



function deleteIssue(issueId) {
  const issues = getIssues();

  const updatedIssues = issues.filter(function (issue) {
    return issue.id !== issueId;



  });

  saveData(STORAGE_KEYS.ISSUES, updatedIssues);

  renderIssues();
  updateIssueCounts();
  filterIssues();
} 



function handleDeleteIssue() {
  if (currentViewedIssueId === null) return;

  const confirmed = window.confirm("Are you sure you want to delete this issue?");

  if (!confirmed) return;



  deleteIssue(currentViewedIssueId);

  const viewModalElement = document.getElementById("viewIssueModal");
  const viewModalInstance = bootstrap.Modal.getInstance(viewModalElement);

  if (viewModalInstance) {
    viewModalInstance.hide();
  }

  currentViewedIssueId = null;





}


function populateProjectOptions() {
  const projectSelect = document.getElementById("projectId");
  if (!projectSelect) return;

  const projects = getProjects();






  projectSelect.innerHTML = '<option value="">Select project</option>';

  projects.forEach(function (project) {
    projectSelect.innerHTML += `<option value="${project.id}">${project.name}</option>`;
  });
}

function populatePeopleOptions() {
  const assignedToSelect = document.getElementById("assignedTo");
  if (!assignedToSelect) return;

  const people = getPeople();







  assignedToSelect.innerHTML = '<option value="">Unassigned</option>';

  people.forEach(function (person) {
    assignedToSelect.innerHTML += `<option value="${person.id}">${person.name} ${person.surname}</option>`;
  });
}


function handleCreateIssue(event) {
  event.preventDefault();

  const issues = getIssues();

  const newIssue = {
    id: issues.length ? issues[issues.length - 1].id + 1 : 1,
    summary: document.getElementById("summary").value.trim(),
    description: document.getElementById("description").value.trim(),
    identifiedBy: document.getElementById("identifiedBy").value.trim(),
    dateIdentified: document.getElementById("dateIdentified").value,
    projectId: Number(document.getElementById("projectId").value),
    assignedTo: document.getElementById("assignedTo").value
      ? Number(document.getElementById("assignedTo").value)







      : null,
    status: document.getElementById("status").value,
    priority: document.getElementById("priority").value,
    targetResolutionDate: document.getElementById("targetResolutionDate").value,
    actualResolutionDate: document.getElementById("actualResolutionDate").value,
    resolutionSummary: document.getElementById("resolutionSummary").value.trim(),



  };


  issues.push(newIssue);
  saveData(STORAGE_KEYS.ISSUES, issues);

  renderIssues();
  updateIssueCounts();
  filterIssues();

  const form = document.getElementById("createIssueForm");
  if (form) form.reset();

  const modalElement = document.getElementById("createIssueModal");
  const modalInstance = bootstrap.Modal.getInstance(modalElement);
  if (modalInstance) {
    modalInstance.hide();
  }
}












function getIssueById(issueId) {
  const issues = getIssues();
  return issues.find(function (issue) {
    return issue.id === issueId;
  });
}

function createIssueDetailsHTML(issue) {
  const assignedPerson = getPersonById(issue.assignedTo);



  const project = getProjectById(issue.projectId);

  return `
    <div class="row g-3">
      <div class="col-md-6">
        <p><strong>Summary:</strong><br>${issue.summary}</p>
      </div>
      <div class="col-md-6">
        <p><strong>Identified By:</strong><br>${issue.identifiedBy}</p>
      </div>

      <div class="col-12">








        <p><strong>Description:</strong><br>${issue.description}</p>
      </div>

      <div class="col-md-6">
        <p><strong>Project:</strong><br>${project ? project.name : "Unassigned"}</p>
      </div>
      <div class="col-md-6">
        <p><strong>Assigned To:</strong><br>${assignedPerson ? assignedPerson.name + " " + assignedPerson.surname : "Unassigned"}</p>
      </div>

      <div class="col-md-4">
        <p><strong>Status:</strong><br>
          <span class="badge ${getStatusBadgeClass(issue.status)} text-uppercase">${issue.status}</span>
        </p>
      </div>
      <div class="col-md-4">
        <p><strong>Priority:</strong><br>
          <span class="badge ${getPriorityBadgeClass(issue.priority)} text-uppercase">${issue.priority}</span>
        </p>
      </div>

      <div class="col-md-4">
        <p><strong>Date Identified:</strong><br>${issue.dateIdentified}</p>
      </div>



      <div class="col-md-6">
        <p><strong>Target Resolution Date:</strong><br>${issue.targetResolutionDate || "Not set"}</p>
      </div>
      <div class="col-md-6">
        <p><strong>Actual Resolution Date:</strong><br>${issue.actualResolutionDate || "Not set"}</p>
      </div>

      <div class="col-12">
        <p><strong>Resolution Summary:</strong><br>${issue.resolutionSummary || "No resolution summary yet."}</p>
      </div>
    </div>
  `;
}

function openIssueDetails(issueId) {
  const issue = getIssueById(issueId);
  const viewIssueContent = document.getElementById("viewIssueContent");

  if (!issue || !viewIssueContent) return;

  currentViewedIssueId = issueId;







  viewIssueContent.innerHTML = createIssueDetailsHTML(issue);

  const modalElement = document.getElementById("viewIssueModal");
  const modalInstance = new bootstrap.Modal(modalElement);
  modalInstance.show();
}



function openEditIssueModal(issueId) {
  const issue = getIssueById(issueId);
  if (!issue) return;

  document.getElementById("editIssueId").value = issue.id;
  document.getElementById("editSummary").value = issue.summary;
  document.getElementById("editDescription").value = issue.description;
  document.getElementById("editIdentifiedBy").value = issue.identifiedBy;
  document.getElementById("editDateIdentified").value = issue.dateIdentified;
  document.getElementById("editProjectId").value = issue.projectId || "";
  document.getElementById("editAssignedTo").value = issue.assignedTo || "";

  document.getElementById("editStatus").value = issue.status;
  document.getElementById("editPriority").value = issue.priority;
  document.getElementById("editTargetResolutionDate").value = issue.targetResolutionDate || "";
  document.getElementById("editActualResolutionDate").value = issue.actualResolutionDate || "";
  document.getElementById("editResolutionSummary").value = issue.resolutionSummary || "";

  const viewModalElement = document.getElementById("viewIssueModal");
  const viewModalInstance = bootstrap.Modal.getInstance(viewModalElement);
  if (viewModalInstance) {
    viewModalInstance.hide();
  }

  const editModalElement = document.getElementById("editIssueModal");
  const editModalInstance = new bootstrap.Modal(editModalElement);
  editModalInstance.show();
}











function populateEditProjectOptions() {
  const projectSelect = document.getElementById("editProjectId");
  if (!projectSelect) return;

  const projects = getProjects();

  projectSelect.innerHTML = '<option value="">Select project</option>';

  projects.forEach(function (project) {
    projectSelect.innerHTML += `<option value="${project.id}">${project.name}</option>`;
  });
}

function populateEditPeopleOptions() {
  const assignedToSelect = document.getElementById("editAssignedTo");
  if (!assignedToSelect) return;

  const people = getPeople();

  assignedToSelect.innerHTML = '<option value="">Unassigned</option>';

  people.forEach(function (person) {
    assignedToSelect.innerHTML += `<option value="${person.id}">${person.name} ${person.surname}</option>`;
  });
}






function handleEditIssue(event) {
  event.preventDefault();

  const issueId = Number(document.getElementById("editIssueId").value);
  const issues = getIssues();

  const issueIndex = issues.findIndex(function (issue) {
    return issue.id === issueId;
  });

  if (issueIndex === -1) return;

  issues[issueIndex] = {
    id: issueId,




    summary: document.getElementById("editSummary").value.trim(),
    description: document.getElementById("editDescription").value.trim(),
    identifiedBy: document.getElementById("editIdentifiedBy").value.trim(),
    dateIdentified: document.getElementById("editDateIdentified").value,
    projectId: Number(document.getElementById("editProjectId").value),
    assignedTo: document.getElementById("editAssignedTo").value
      ? Number(document.getElementById("editAssignedTo").value)
      : null,
    status: document.getElementById("editStatus").value,
    priority: document.getElementById("editPriority").value,
    targetResolutionDate: document.getElementById("editTargetResolutionDate").value,
    actualResolutionDate: document.getElementById("editActualResolutionDate").value,
    resolutionSummary: document.getElementById("editResolutionSummary").value.trim(),
  };

  saveData(STORAGE_KEYS.ISSUES, issues);

  renderIssues();
  updateIssueCounts();
  filterIssues();

  const editModalElement = document.getElementById("editIssueModal");
  const editModalInstance = bootstrap.Modal.getInstance(editModalElement);
  if (editModalInstance) {
    editModalInstance.hide();
  }

  openIssueDetails(issueId);
}


function getIssueAccentClass(status) {
  if (status === "open") return "issue-accent-open";
  if (status === "resolved") return "issue-accent-resolved";
  if (status === "overdue") return "issue-accent-overdue";
  return "issue-accent-default";
}

function renderRecentIssues() {
  const container = document.getElementById("recentIssuesList");
  if (!container) return;

  const issues = getIssues();








  const recent = issues.slice(-5).reverse();

  const html = recent.map(issue => `
    <div class="recent-issue-item">
      <div class="recent-issue-title">${issue.summary}</div>
      <div class="recent-issue-badges">
        <span class="badge ${getStatusBadgeClass(issue.status)}">${issue.status}</span>
        <span class="badge ${getPriorityBadgeClass(issue.priority)}">${issue.priority}</span>
      </div>
    </div>
  `);

  container.innerHTML = html.join("");
}