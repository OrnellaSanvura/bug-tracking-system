
# Bug Tracking System
 This is a web-based application that is used to store, assign, manage and monitor project issues.
 This web based application allows and supports light and dark themes, styled dashboards and intuitive issue management

 ---


 ## Overview
 The bug Tracking System helps the administrators and teams track software issues accross projects, assigns them to team members,
 and monitor their progress from creation to resolution.

 ---

 ## Purpose
 - Provides a centralised dashboard for monitoring issues.
 - Enables assignment of issues to people and projects.
 - Persist data using localStorage for continuity.
 - Presents a clean, responsive UI with light/dark themes

 
 ---


 ## Features
 - **Dashboard (index.html)**
 - Summary cards for open, resolved and overdue issues
 - Includes filters for searching, status, and priority
 - Recent issues panel showing latest activity.
 - Issue board with detailed ticket cards.
 - Models for creating, viewing and editing issues


 - **Issue page (issue.html)**
 - Placeholder for detailed issue view.
 - Designed to integrate with dashboard issue cards.


 - **People page (people.html)**
 - Team directory with profile cards.
 - Displays name, username, role, years of experience, tickets completed and contact information.
 - Empty state message if no person/people exist.


 - **Projects page(projects.html)**
 - Project directory with expandable project items.
 - Shows project ID, created date and issue statistics (total, open, resolved, overdue).
 - Toggle functionality for expanding/collapsing details.

 
 - **Docs page(docs.html)**
 - In-app documentation explaining the purpose, features, the workflow and the technologies.

 - **Theme toggle**
 - Abilitly to switch between light and dark modes.
 Preference saved in localStorage.

 ---

 ## Date Model
 - ***Issues***
 -  `id, summary, description, identifiedBy, dateIdentified, projectId, assignedTo, status, priority, targetResolutionDate, actualResolutionDate, resolutionSummary`

 - ***People***
 - `id, name, surname, email, username, profilePicture, yearsExperience, role`

 - ***Projects***
 - `id, name, createdDate`


 ---

## Workflow
- The application always follows a basic issue lifecycle:

**Create --> Assign --> View --> Edit --> Persist**

- Create issues through the modal form.
- Assigns the issues to people and projects.
- View issues in the dashboard for detail modal.
- Edit/update issue information.
- Persist data in localStorage.

---

## Technology Stack
- **HTML** - structure of pages.
- **CSS (styles.css)** - custom styling, responsive design, light/dark themes.
- **Bootstrap 5** - layout and components.
- **JavaScript** - application logic and interactivity.
- **localStorage** - persistence of issues, people and projects.

---

## File Structure
- `index.html` - Dashboard with summary cards, filters , issue board and modals.
- `issue.html` - Placeholder for single issue view.
- `people.html` - Team directory with profile cards.
- `projects.html` - Project directory with expandable items.
- `docs.html` - Documentation page inside the app.
- `styles.css` - Styling for all pages.
- `app.js` - Coordinates theme, dashboard, people, and project logic.
- `issues.js` - Full issue lifecycle managment (create, view, edit, delete, filter).
- `people.js` - Renders people cards and tracks completed tickets.
- `projects.js` - Renders projects and calculates issue statistics.
- `seed.js` - Seeds initial data (6 people, 3 projects, 10 issues).
- `storage.js` - handles localStorage persistence (get, save, clear).


---


## Setup Instructions
This list shows the steps taken in order to set up the application.

1. Clone or download the project repository.
2. Open `index.html` in a browser.
3. The app will automatically seed sample data if localStorage is empty.
4. Use the dashboard to create, assign, view, edit, and delete issues.
5. Navigate to people, projects and document pages through the navigation bar.
6. Toggle between light/dark themes using the button in the navigation bar.

---

## Credits
***GROUP MEMBERS***
**Timothy Gobey - 605080**
**Gina Gin - 601655**
**Daniel Danilowitz - 605150**
**Ornella Sanvura - 603565**

---

## Key Takeaways
- The Bug Tracking System is a complete web-based issue tracker.  
- It integrates people, projects, and issues with persistence via localStorage.  
- Provides a responsive UI with light/dark themes.  
- Includes in-app documentation and external README.md for clarity.  





